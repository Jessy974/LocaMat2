﻿using LocaMat.UI;

namespace LocaMat
{
    class Program
    {
        static void Main(string[] args)
        {
            var application = new Application();
            application.Demarrer();
        }
    }
}
