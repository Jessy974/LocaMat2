﻿using System;
using System.Collections.Generic;
using LocaMat.Metier;
using LocaMat.UI.Framework;

namespace LocaMat.UI
{
    public class ModuleGestionProduits
    {
        private Menu menu;

        private void InitialiserMenu()
        {
            this.menu = new Menu("Gestion des produits");
            this.menu.AjouterElement(new ElementMenu("1", "Afficher les produits")
            {
                FonctionAExecuter = this.AfficherProduits
            });
            this.menu.AjouterElement(new ElementMenu("2", "Ajouter un produit")
            {
                FonctionAExecuter = this.AjouterProduit
            });
            this.menu.AjouterElement(new ElementMenuQuitterMenu("R", "Revenir au menu principal..."));
        }

        public void Demarrer()
        {
            if (this.menu == null)
            {
                this.InitialiserMenu();
            }

            this.menu.Afficher();
        }

        private void AfficherProduits()
        {
            ConsoleHelper.AfficherEntete("Produits");

            var liste = new List<Produit>{
                new Produit{Id = 1, Nom = "Tondeuse",  PrixJourHT = 120.50m, Categorie = new CategorieProduit {Id = 1, Libelle = "Jardinage" } }
            };

            ConsoleHelper.AfficherListe(liste);


            Console.WriteLine("TO DO");
        }

        private void AjouterProduit()
        {
            ConsoleHelper.AfficherEntete("Nouveau produit");

            Console.WriteLine("TO DO");
        }
    }
}
